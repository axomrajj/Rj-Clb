// Past results history (initial sample data)

let pastResults = ["Green", "Red", "Green", "Red", "Purple", "Green", "Red", "Green"];

// AI-based prediction: Sirf 3 colors use karke, Purple kam probability pe

function predictNextColor() {

    let colorCounts = { "Green": 0, "Red": 0, "Purple": 0 };

    

    pastResults.forEach(color => {

        colorCounts[color]++;

    });

    

    // Weights for each color; Purple ko kam dikhane ke liye divide kiya

    let greenWeight = colorCounts["Green"];

    let redWeight = colorCounts["Red"];

    let purpleWeight = colorCounts["Purple"] / 2; // Purple kam chance pe

    

    let totalWeight = greenWeight + redWeight + purpleWeight;

    let random = Math.random() * totalWeight;

    

    if(random < greenWeight) return "Green";

    else if(random < greenWeight + redWeight) return "Red";

    else return "Purple";

}

// Start button click event

document.querySelector(".start-btn").addEventListener("click", function () {

    let periodInput = document.querySelector(".period-input").value.trim();

    let resultBox = document.querySelector(".result-box");

    // Agar period number empty hai toh error message show kare

    if (periodInput === "") {

        resultBox.innerHTML = "<p class='result-text' style='color: red;'>Please enter period number</p>";

        return;

